# ChallengeMeli

Buenas tardes gracias invitarme hacer este reto
 
Incluyo la medio documentacion que logre hacer del mismo 

# Contruccion

## Design Pattern

MVVM

## Librerias

1. Alamifire
2. SDWebImage 

# Servicios 

 https://developers.mercadolibre.com.ar/es_ar/api-prediccion-categorias


 Muchas gracias.
 
 Julian David Perez Gomez
